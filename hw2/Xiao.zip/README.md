Xiao Zhou, 6021349
Didn't do the bonus part